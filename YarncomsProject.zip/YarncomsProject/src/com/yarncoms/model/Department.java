package com.yarncoms.model;

public class Department {

}
